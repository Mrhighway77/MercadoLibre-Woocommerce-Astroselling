# MercadoLibre-WooCommerce-Sales-Integration
Integración de la API de Mercado Libre para registrar automáticamente las ventas en WooCommerce. Este repositorio permite extraer datos de ventas de Mercado Libre, mapear productos por SKU y crear pedidos en WooCommerce, simplificando la gestión de órdenes entre ambas plataformas.
